/* globals Vue */

import getDefaultOptions from './defaultOptions.js';

const defaultOptions = getDefaultOptions();

// eslint-disable-next-line no-new
new Vue({
  el: '#options',
  data: {
    loading: true,
    ...defaultOptions,
  },
  watch: (() => {
    const obj = {};
    Object.keys(defaultOptions).forEach((key) => {
      obj[key] = {
        handler(value) {
          this.updateOptions(key, value);
        },
      };
    });
    return obj;
  })(),
  created() {
    this.init().catch(e => console.log(e));
  },
  methods: {
    async init() {
      const options = await browser.runtime.sendMessage({ msg: 'get-options' });
      Object.keys(defaultOptions).forEach((key) => {
        this[key] = options[key];
      });
      setTimeout(() => { this.loading = false; }, 0);
    },
    updateOptions(key, value) {
      if (!this.loading) {
        browser.runtime.sendMessage({ msg: 'update-options', key, value });
      }
    },
  },
});
