export default function defaultOptions() {
  return {
    changeUserAgent: false,
  };
}
