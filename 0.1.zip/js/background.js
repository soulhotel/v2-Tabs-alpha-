import defaultOptions from './defaultOptions.js';

class OpenInSidebar {
  constructor() {
    const FIREFOX_VERSION = /rv:([0-9.]+)/.exec(navigator.userAgent)[1];
    this.MOBILE_USER_AGENT = `Mozilla/5.0 (Android 4.4; Mobile; rv:${FIREFOX_VERSION}) Gecko/${FIREFOX_VERSION} Firefox/${FIREFOX_VERSION}`;
    this.EXT_ORIGIN = browser.runtime.getURL('/');
    this.options = defaultOptions();
    this.sendMobileUserAgent = this._sendMobileUserAgent.bind(this);
  }

  async init() {
    const result = await browser.storage.local.get(Object.keys(this.options));
    Object.assign(this.options, result);
    this.createMenuItems();
    this.toggleUserAgentChanger();
    browser.runtime.onMessage.addListener(this.messageListener.bind(this));
  }

  messageListener(message, sender, sendResponse) {
    switch (message.msg) {
      case 'get-options': sendResponse(this.options); break;
      case 'update-options': this.updateOptions(message); break;
      default:
    }
  }

  createMenuItems() {
    const items = [
      {
        id: 'open-link-in-sidebar',
        title: 'open Link in Sidebar',
        contexts: ['link'],
      },
      {
        id: 'open-page-in-sidebar',
        title: 'view in 2 tabs',
        contexts: ['page', 'tab'],
      },
      {
        id: 'open-bookmark-in-sidebar',
        title: 'view in 2 tabs',
        contexts: ['bookmark'],
      },
    ];

    items.forEach(item => browser.menus.create(item));

    browser.menus.onClicked.addListener(this.onMenuClicked.bind(this));
  }

  onMenuClicked(info) {
    browser.sidebarAction.open();
    if ('linkUrl' in info) {
      this.openUrl(info.linkUrl);
    } else if ('pageUrl' in info) {
      this.openUrl(info.pageUrl);
    } else if ('bookmarkId' in info) {
      browser.bookmarks.get(info.bookmarkId).then(([bookmark]) => this.openUrl(bookmark.url));
    }
  }

  openUrl(url) {
    browser.sidebarAction.setPanel({ panel: 'about:blank' });
    browser.sidebarAction.setPanel({ panel: url });
  }

  toggleUserAgentChanger() {
    const shouldChange = this.options.changeUserAgent;
    const onBeforeSendHeaders = browser.webRequest.onBeforeSendHeaders;
    const hasListener = onBeforeSendHeaders.hasListener(this.sendMobileUserAgent);
    if (shouldChange && !hasListener) {
      const requestFilter = {
        tabId: -1,
        types: ['main_frame'],
        urls: ['http://*/*', 'https://*/*'],
      };
      onBeforeSendHeaders.addListener(this.sendMobileUserAgent, requestFilter, ['blocking', 'requestHeaders']);
    } else if (!shouldChange && hasListener) {
      onBeforeSendHeaders.removeListener(this.sendMobileUserAgent);
    }
  }

  _sendMobileUserAgent(info) {
    if (info.originUrl !== this.EXT_ORIGIN) {
      return {};
    }
    const headers = info.requestHeaders;
    for (let i = 0; i < headers.length; i++) {
      const name = headers[i].name.toLowerCase();
      if (name === 'user-agent') {
        headers[i].value = this.MOBILE_USER_AGENT;
        return { requestHeaders: headers };
      }
    }
    return {};
  }

  updateOptions({ key, value }) {
    if (!(key in this.options)) {
      return;
    }
    this.options[key] = value;
    if (key === 'changeUserAgent') {
      this.toggleUserAgentChanger();
    }
    if (this.options[key] === defaultOptions()[key]) {
      browser.storage.local.remove(key).catch(e => console.log(e));
    } else {
      browser.storage.local.set({ [key]: this.options[key] }).catch(e => console.log(e));
    }
  }
}

new OpenInSidebar().init().catch(e => console.log(e));
